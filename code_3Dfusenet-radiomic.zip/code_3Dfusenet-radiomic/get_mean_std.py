import pandas as pd
import glob

file_paths = glob.glob("2026_1_NA2GTR_kfold*.csv")
dfs = [pd.read_csv(f) for f in file_paths]
df = pd.concat(dfs, ignore_index=True)

metrics = ["MAE", "RMSE", "C-index", "SpearmanR", "p-value", "hr"]

# 确保数值列是数字
for col in metrics:
    df[col] = pd.to_numeric(df[col], errors='coerce')

# 按 TraditionModel 分组，计算均值和标准差
result = df.groupby("TraditionModel")[metrics].agg(["mean", "std"])

# 展平列名
result.columns = ['_'.join(col) for col in result.columns]

# 打印结果（会显示每行一个模型）
print(result.round(4))

# 如果有 NaN 的 std，打印每组样本数检查
print("\n每组样本数：\n", df.groupby("TraditionModel").size())
