import pandas as pd
import numpy as np
import glob

files = sorted(glob.glob("mean_val/*_kfold*.csv"))
col_names = ['Optim', 'TraditionModel', 'MAE', 'RMSE', 'C-index', 'SpearmanR']
dfs = [pd.read_csv(f, usecols=range(6), names=col_names, header=0) for f in files]

models = [df['TraditionModel'].tolist() for df in dfs]
for i in range(1, len(models)):
    assert models[i] == models[0], f"Fold {i} model order mismatch!"

model_names = models[0]

metrics = ['MAE', 'RMSE', 'C-index', 'SpearmanR']
data = {m: [] for m in metrics}
for df in dfs:
    for m in metrics:
        data[m].append(df[m].values)

print("=" * 94)
print(f"{'Model':<22} {'MAE':<18} {'RMSE':<18} {'C-index':<18} {'SpearmanR':<18}")
print("=" * 94)

for i, name in enumerate(model_names):
    parts = [f"{name:<22}"]
    for m in metrics:
        vals = [data[m][k][i] for k in range(5)]
        mean = np.mean(vals)
        std = np.std(vals, ddof=1) 
        if m in ['MAE', 'RMSE']:
            parts.append(f"{mean:.2f}±{std:.2f}".ljust(18))
        else:
            parts.append(f"{mean:.4f}±{std:.4f}".ljust(18))
    print("".join(parts))

print("=" * 94)