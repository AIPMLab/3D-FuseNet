import pandas as pd
import torch
import torchextractor as tx
from pathlib import Path
from rich.progress import Progress, TextColumn
from dataloader import BraTSDataset
import numpy as np
from torch.utils.data import DataLoader
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from sklearn.linear_model import LinearRegression
from sklearn.neighbors import KNeighborsRegressor
from lifelines.utils import concordance_index
from scipy.stats import pearsonr, spearmanr
from sklearn.metrics import mean_absolute_error, mean_squared_error
import pingouin as pg
import matplotlib.pyplot as plt
from lifelines import CoxPHFitter
from lifelines.statistics import logrank_test


def rf():
    return RandomForestRegressor(random_state=42)


def svrp():
    return SVR(kernel="poly")


def svrr():
    return SVR()


def lr():
    return LinearRegression()


def knn():
    return KNeighborsRegressor()

def coxph():
    from lifelines import CoxPHFitter
    return CoxPHFitter(penalizer=0.01)


def deepsurv(in_features=10):
    import torch
    import torchtuples as tt
    from pycox.models import CoxPH
    
    net = tt.practical.MLPVanilla(in_features, [32,32], 1, batch_norm=True, dropout=0.1)
    model = CoxPH(net, torch.optim.Adam)   #  DeepSurv cause with a net in it
    return model

plt.rcParams['font.family'] = ['Times New Roman']
module_path = Path(r"D:\vit_reg\Only_3d_4")

device = "cuda:0"
fold_ = 0

train_dataset = BraTSDataset(
    r"D:\yolov9\BraTS2020_TrainingData\MICCAI_BraTS2020_TrainingData", "train")
train_dataloader = DataLoader(train_dataset,
                              batch_size=1,
                              shuffle=False,
                              pin_memory=True)
val_dataset = BraTSDataset(
    r"D:\yolov9\BraTS2020_TrainingData\MICCAI_BraTS2020_TrainingData", "val")
val_dataloader = DataLoader(val_dataset,
                            batch_size=1,
                            shuffle=False,
                            pin_memory=True)
test_dataset = BraTSDataset(
    r"D:\yolov9\BraTS2020_TrainingData\MICCAI_BraTS2020_TrainingData", "test")
test_dataloader = DataLoader(test_dataset,
                             batch_size=1,
                             shuffle=False,
                             pin_memory=True)

name = [
    "Optim", "TraditionModel", "MAE", "RMSE", "C-index", "SpearmanR",
    "p-value", "hr", "95%-ci"
]

fig, axs = plt.subplots(5, 2, figsize=(10, 15), constrained_layout=True)
features_layer = "decoder_model.2" # 512
features_layer = "decoder_model.5" # 64
features_layer = "output_model.2"
with open(f"deep_clinical_deepsurv_coxph.csv", "w", encoding="UTF-8") as f:
    f.write(",".join(name) + "\n")
    for num, optim in enumerate(p for p in module_path.iterdir()
                                if p.is_dir()):
        if optim.name.lower() != "rprop":
            continue
        model = torch.load(optim / "model" / "best_epoch.pth")
        extract_model = tx.Extractor(model, [features_layer]).to(device)

        x_train_feature = []
        y_train = []
        with torch.no_grad(), Progress(
                *Progress.get_default_columns(),
                TextColumn(
                    "Loss={task.fields[loss]}, MSE={task.fields[mse]}")) as p:
            task = p.add_task("Testing", loss=0, mse=0)
            for i, (data, survival_day, age, resection) in enumerate(
                    p.track(train_dataloader, task_id=task), 1):
                data, survival_day, age, resection = data.to(
                    device), survival_day.to(device), age.to(
                        device), resection.to(device)
                _, features = extract_model(data)
                #result = model(data, age, resection)
                x_train_feature.append(
                    np.hstack([
                        features[features_layer].detach().cpu().numpy().
                        flatten(),
                        age.detach().cpu().numpy().flatten(),
                        resection.detach().cpu().numpy().flatten(),
                    ]))
                y_train.append(survival_day.cpu().numpy()[0][0])

        with torch.no_grad(), Progress(
                *Progress.get_default_columns(),
                TextColumn(
                    "Loss={task.fields[loss]}, MSE={task.fields[mse]}")) as p:
            task = p.add_task("Testing", loss=0, mse=0)
            for i, (data, survival_day, age, resection) in enumerate(
                    p.track(val_dataloader, task_id=task), 1):
                data, survival_day, age, resection = data.to(
                    device), survival_day.to(device), age.to(
                        device), resection.to(device)
                _, features = extract_model(data)
                #result = model(data, age, resection)
                x_train_feature.append(
                    np.hstack([
                        features[features_layer].detach().cpu().numpy().
                        flatten(),
                        age.detach().cpu().numpy().flatten(),
                        resection.detach().cpu().numpy().flatten(),
                    ]))
                y_train.append(survival_day.cpu().numpy()[0][0])

        x_test_feature = []
        y_test = []
        with torch.no_grad(), Progress(
                *Progress.get_default_columns(),
                TextColumn(
                    "Loss={task.fields[loss]}, MSE={task.fields[mse]}")) as p:
            task = p.add_task("Testing", loss=0, mse=0)
            for i, (data, survival_day, age, resection) in enumerate(
                    p.track(test_dataloader, task_id=task), 1):
                data, survival_day, age, resection = data.to(
                    device), survival_day.to(device), age.to(
                        device), resection.to(device)
                _, features = extract_model(data)
                #result = model(data, age, resection)
                x_test_feature.append(
                    np.hstack([
                        features[features_layer].detach().cpu().numpy().
                        flatten(),
                        age.detach().cpu().numpy().flatten(),
                        resection.detach().cpu().numpy().flatten(),
                    ]))
                y_test.append(survival_day.cpu().numpy()[0][0])

        # X_train_raw = np.asarray(x_train_feature)
        # X_test_raw  = np.asarray(x_test_feature)
        # deep_cols = slice(0, 8)
        # train_deep_std = X_train_raw[:, deep_cols].std(axis=0, keepdims=True)
        # train_deep_std[train_deep_std == 0] = 1.0
        # x_train_feature = X_train_raw.copy()
        # x_test_feature  = X_test_raw.copy()
        # x_train_feature[:, deep_cols] /= train_deep_std
        # x_test_feature[:, deep_cols]  /= train_deep_std
        # print(x_train_feature[:, deep_cols].var(axis=0))
        x_train_feature = np.asarray(x_train_feature)
        x_test_feature  = np.asarray(x_test_feature)

        all_var = x_train_feature.var(axis=0)

        threshold = 1e-12
        low_var_idx = np.where(all_var < threshold)[0]
        if len(low_var_idx) > 0:
            print(f" {len(low_var_idx)} std < {threshold:.0e}）, index: {low_var_idx}")
            keep_cols = np.ones(x_train_feature.shape[1], dtype=bool)
            keep_cols[low_var_idx] = False
            x_train_feature = x_train_feature[:, keep_cols]
            x_test_feature  = x_test_feature[:, keep_cols]

        output = []
        nc = {
            "rf": "Random Forest",
            "svrp": "SVR(poly kernel)",
            "svrr": "SVR(rbf kernel)",
            "lr": "Linear Regression",
            "knn": "K Nearest Regression",
            "coxph": "Cox PH",
            "deepsurv": "DeepSurv"
        }
        for i in [ coxph, deepsurv]:
            model_name = i.__name__

            # 实例化
            if model_name == 'deepsurv':
                tmodel = i(in_features=np.array(x_train_feature).shape[1])
            else:
                tmodel = i()

            # ---------- 训练与预测 ----------
            if model_name in ['coxph', 'deepsurv']:
                # ----- 生存模型分支 -----
                if model_name == 'coxph':
                    variances = np.var(x_train_feature, axis=0)
                    print(variances)
                    # 准备训练 DataFrame
                    if not isinstance(x_train_feature, pd.DataFrame):
                        train_df = pd.DataFrame(x_train_feature)
                    else:
                        train_df = x_train_feature.copy()
                    train_df['time'] = y_train
                    train_df['event'] = 1  # 全部视为事件
                    tmodel.fit(train_df, duration_col='time', event_col='event',)

                    # 准备测试 DataFrame
                    if not isinstance(x_test_feature, pd.DataFrame):
                        test_df = pd.DataFrame(x_test_feature)
                    else:
                        test_df = x_test_feature
                    y_pred = tmodel.predict_partial_hazard(test_df).values.flatten()

                    # ---- 新增：定义变量 ----
                    y_test_ret = test_dataset.scaler.inverse_transform(
                        np.array(y_test).reshape(-1, 1)
                    ).flatten()                 # 真实时间（原始尺度）
                    y_pred_ret = y_pred          # 风险分数（不反标准化）

                else:  # deepsurv
                    X_train = np.asarray(x_train_feature)
                    T_train = np.asarray(y_train).flatten()
                    E_train = np.ones_like(T_train)
                    tmodel.fit(X_train, (T_train, E_train),
                            batch_size=8, epochs=200, verbose=0)

                    X_test = np.asarray(x_test_feature)
                    y_pred = tmodel.predict(X_test).flatten()

                    # ---- 已定义，但确保一致 ----
                    y_test_ret = test_dataset.scaler.inverse_transform(
                        np.array(y_test).reshape(-1, 1)
                    ).flatten()
                    y_pred_ret = y_pred          # 风险分数

            else:
                # ----- 回归模型分支（保持不变） -----
                tmodel.fit(x_train_feature, y_train)
                y_pred = tmodel.predict(x_test_feature)
                y_test_ret = test_dataset.scaler.inverse_transform(
                    np.array(y_test).reshape(-1, 1)
                ).flatten()
                y_pred_ret = test_dataset.scaler.inverse_transform(
                    np.array(y_pred).reshape(-1, 1)
                ).flatten()

            # ---------- 后续评估（加入条件判断） ----------
            all_data = pd.DataFrame({
                "time": y_test_ret.tolist() + y_pred_ret.tolist(),
                "event": [1] * len(y_test_ret) + [1] * len(y_pred_ret),
                "type": [0] * len(y_test_ret) + [1] * len(y_pred_ret)
            })
            cph = CoxPHFitter()
            cph.fit(all_data, duration_col='time', event_col='event')
            variable = 'type'
            p_value_a = cph.summary.loc["type", 'p']
            p_value = logrank_test(y_test_ret, y_pred_ret).p_value
            hr = cph.summary.loc["type", 'exp(coef)']
            ci_lower = cph.summary.loc[variable, 'exp(coef) lower 95%']
            ci_upper = cph.summary.loc[variable, 'exp(coef) upper 95%']

            # ---------- 条件计算 MAE / RMSE ----------
            if model_name in ['coxph', 'deepsurv']:
                mae = np.nan          # 或 "NA"
                rmse = np.nan
            else:
                mae = mean_absolute_error(y_test_ret, y_pred_ret)
                rmse = mean_squared_error(y_test_ret, y_pred_ret) ** 0.5

            # 其余指标（C-index, Spearman ρ）照常计算（合理）
            if model_name in ['coxph', 'deepsurv']:
                cindex = concordance_index(y_test_ret, -y_pred_ret) 
                sr = spearmanr(y_test_ret, -y_pred_ret)[0]
            else:
                cindex = concordance_index(y_test_ret, y_pred_ret)
                sr = spearmanr(y_test_ret, y_pred_ret)[0]
            ns = [
                optim.name,
                model_name,
                mae,
                rmse,
                cindex,   # 风险分数 vs 时间
                sr,
                p_value,
                hr,
                f"[{ci_lower:.4f},{ci_upper:.4f}]"
            ]
            f.write(",".join(map(str, ns)) + "\n")